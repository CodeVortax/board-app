rootProject.name = "board"
include(":app")
